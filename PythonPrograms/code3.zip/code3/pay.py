inp = input('Enter Hours: ')
hours = float(inp)
inp = input('Enter Rate: ')
rate = float(inp)
pay = hours * rate
print('Pay:', pay)
